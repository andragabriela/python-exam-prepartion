from Business.service import ServiceParcare
from Infrastrunctura.repozitorii import FileRepoParcari
from Interfata.consola import Consola
from Teste.teste import Teste

teste=Teste()
teste.run_all_teste()
repo=FileRepoParcari("parcari.txt")
srv=ServiceParcare(repo)

ui=Consola(srv)
ui.run()