from Domain.entitati import Parcare
from Validare.valideaza import ValidatorParcare


class RepoParcari:
    def __init__(self):
        """
        functia constructor cu lista parcarilor
        """
        self._parcari=[]
    def get_all(self):
        """
        functie care returneaza toate parcarile din lista
        :return: toate parcarile din lista
        """
        return self._parcari[:]
    def get_all_locuri(self, strada):
        """
        functie care face o lista cu parcarile de pe strada data
        :param strada: string
        :return: lista cu parcarile de pe strada data
        """
        answear=[]
        for parcare in self._parcari:
            if strada in parcare.get_strada().lower():
                answear.append(parcare)
        return answear
    def get_parcare_utilizata(self):
        """
        functie care returneaza lista de parcari dupa ce afla numarul maxim de utilizari ale unei parcari de pe o strada
        :return: lista cu numele strazii si numele parcarii
        """
        rasp={}
        for parcare in self._parcari:
            if parcare.get_strada() not in rasp.keys():
                rasp[parcare.get_strada()]=[parcare.get_nume(), parcare.get_nrutilizari()]
            else:
                if rasp[parcare.get_strada()][1]<parcare.get_nrutilizari():
                    rasp[parcare.get_strada()] = [parcare.get_nume(), parcare.get_nrutilizari()]
        answear={}
        for strada in rasp.keys():
            answear[strada]=rasp[strada][0]
        return answear
class FileRepoParcari(RepoParcari):
    def __init__(self, filepath):
        self.__filepath = filepath
        RepoParcari.__init__(self)
    def get_all_locuri(self, strada):
        """
                functie care face o lista cu parcarile de pe strada data din fisier
                :param strada: string
                :return: lista cu parcarile de pe strada data
                """
        self.__read_from_file()
        return RepoParcari.get_all_locuri(self, strada)
    def get_all(self):
        """
                functie care returneaza toate parcarile din fisier
                :return: toate parcarile din lista
                """
        self.__read_from_file()
        return RepoParcari.get_all(self)
    def get_parcare_utilizata(self):
        """
                functie care returneaza lista de parcari dupa ce afla numarul maxim de utilizari ale unei parcari de pe o strada din fisier
                :return: lista cu numele strazii si numele parcarii
                """
        self.__read_from_file()
        return RepoParcari.get_parcare_utilizata(self)
    def __read_from_file(self):
        """
        functie care citeste din fisier
        :return:
        """
        with open(self.__filepath,"r") as f:
            self._parcari=[]
            lines=f.readlines()
            for line in lines:
                line=line.strip()
                if len(line)>0:
                    parts=line.split(',')
                    idp=int(parts[0])
                    nume=parts[1]
                    strada=parts[2]
                    nr=int(parts[3])
                    parcare=Parcare(idp, nume, strada, nr)
                    ValidatorParcare.valideaza(parcare)
                    self._parcari.append(parcare)

