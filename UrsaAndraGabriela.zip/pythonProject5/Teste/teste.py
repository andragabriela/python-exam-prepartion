from Business.service import ServiceParcare
from Domain.entitati import Parcare
from Infrastrunctura.repozitorii import FileRepoParcari
from Validare.valideaza import ValidatorParcare, ValidationError


class Teste:
    def run_all_teste(self):
        self.__test_creeaza_parcare()
        self.__test_get_all_locuri()
        self.__test_parcare_folosita()
        self.__test_valideaza_date()
    def __test_creeaza_parcare(self):
        idp=1
        nume="W903"
        strada="Dorobantilor"
        nr=9
        parcare=Parcare(idp, nume, strada, nr)
        assert(parcare.get_idp()==idp)
        assert (parcare.get_nume() == nume)
        assert (parcare.get_strada() == strada)
        assert (parcare.get_nrutilizari() == nr)
        assert(parcare.__str__()=="1 W903 Dorobantilor 9")

    def __test_get_all_locuri(self):
        repo=FileRepoParcari("Teste/test.txt")
        srv=ServiceParcare(repo)
        parcari=srv.get_all_locuri("Dorobantilor")
        assert(parcari[0].get_idp()==7)
        assert(parcari[1].get_idp()==97)

    def __test_parcare_folosita(self):
        repo = FileRepoParcari("Teste/test.txt")
        srv = ServiceParcare(repo)
        parcari = srv.get_parcare_utilizata()
        assert(parcari['Dorobantilor']=='W904')
        assert (parcari['Teodor Mihali'] == 'D3X2')

    def __test_valideaza_date(self):
        parcare=Parcare(-97,"","",-9)
        try:
            ValidatorParcare.valideaza(parcare)
            assert(False)
        except ValidationError as ve:
            assert(str(ve)=="id invalid!\nnume invalid!\nstrada invalida!\nnr utilizari invalid!\n")
