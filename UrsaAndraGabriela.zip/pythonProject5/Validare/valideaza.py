class ValidationError(Exception):
    pass


class ValidatorParcare:
    @staticmethod
    def valideaza(parcare):
        err=""
        if parcare.get_idp()<1:
            err+="id invalid!\n"
        if parcare.get_nume()=="":
            err+="nume invalid!\n"
        if parcare.get_strada()=="":
            err+="strada invalida!\n"
        if parcare.get_nrutilizari()<1:
            err+="nr utilizari invalid!\n"
        if len(err)>0:
            raise ValidationError(err)