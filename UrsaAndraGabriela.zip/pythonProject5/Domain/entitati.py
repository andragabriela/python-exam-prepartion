class Parcare:
    def __init__(self, idp, nume, strada, nrutilizari):
        self.__nrutilizari = nrutilizari
        self.__idp=idp
        self.__nume=nume
        self.__strada=strada
    def get_idp(self):
        """
        getter pentru id-ul parcarii
        :return: id-ul
        """
        return self.__idp
    def get_nume(self):
        """
                getter pentru numele parcarii
                :return: numele
                """
        return self.__nume
    def get_strada(self):
        """
                getter pentru strada parcarii
                :return: strada
                """
        return self.__strada
    def get_nrutilizari(self):
        """
                getter pentru nr de utilizari parcarii
                :return: nr de utilizari
                """
        return self.__nrutilizari
    def __str__(self):
        """
        functie pentru printare
        :return: printarea data de mine in formatul de mai jos
        """
        return str(self.__idp)+" "+self.__nume+" "+self.__strada+" "+str(self.__nrutilizari)