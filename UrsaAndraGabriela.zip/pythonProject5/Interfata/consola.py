from Business.service import NoParcari
from Validare.valideaza import ValidationError


class Consola:
    def __init__(self, srv):
        self.__srv = srv
    def run(self):
        while True:
            cmd=input(">>>")
            if cmd=="":
                continue
            if cmd=="exit":
                return
            elif cmd=="afisare_parcari":
                try:
                    self.__ui_parcari_strada()
                except NoParcari as np:
                    print(np)
                except ValidationError as ve:
                    print(ve)
            elif cmd=="cea_mai_utilizata_parcare":
                self.__ui_cea_mai_utilizata_parcare()
            else:
                print("comanda invalida!")

    def __ui_parcari_strada(self):
        strada=input("citeste strada de cautat: ")
        parcari=self.__srv.get_all_locuri(strada)
        for parcare in parcari:
            print(parcare)

    def __ui_cea_mai_utilizata_parcare(self):
        parcari=self.__srv.get_parcare_utilizata()
        for parcare in parcari.keys():
            print(parcare, ":", parcari[parcare])
