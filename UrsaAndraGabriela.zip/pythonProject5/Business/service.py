class NoParcari(Exception):
    pass


class ServiceParcare:
    def __init__(self, repo):
        """
        functia constructor cu parametrii
        :param repo: repozitoriul
        """
        self.__repo = repo
    def get_all(self):
        """
        functie care returneaza toate parcarile din lista
        :return: toate parcarile din lista
        """
        return self.__repo.get_all()
    def get_all_locuri(self, strada):
        """
        functie care ia toate parcarile de pe o strada data si verifica daca exista si orodoneaza descrescator dupa nume
        :param strada: string
        :return: lista cu parcarile de pe strada data in ordine desc dupa nume
        """
        strada=strada.lower()
        parcari=self.__repo.get_all_locuri(strada)
        if len(parcari)==0:
            raise NoParcari("Nu sunt parcari pe acea strada!")
        return sorted(parcari, key=lambda p: p.get_nume(), reverse=True)
    def get_parcare_utilizata(self):
        """
        functie care returneaza lista de parcari dupa ce afla numarul maxim de utilizari ale unei parcari de pe o strada
        :return: lista cu numele strazii si numele parcarii
        """
        return self.__repo.get_parcare_utilizata()